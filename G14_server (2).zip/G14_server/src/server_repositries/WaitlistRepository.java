/*package server_repositries;
//Added By maayan 11.1.26 02:19
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import Server.MySQLConnectionPool;
import Server.PooledConnection;*/



/*public class WaitlistRepository {

    private WaitlistRepository() {}

    /**
     * Represents a successful table offer to a waiting customer.
     * Contains the confirmation code, assigned table number,
     * and number of diners.
     */
    /*public static class Offer {
        public final int confirmationCode;
        public final int tableNum;
        public final int diners;

        public Offer(int confirmationCode, int tableNum, int diners) {
            this.confirmationCode = confirmationCode;
            this.tableNum = tableNum;
            this.diners = diners;
        }
    }*/

    /**
     * Selects the first waiting customer (FIFO order) who can be
     * accommodated by at least one available table.
     * Customers without a suitable table are skipped.
     *
     * @param con Active database connection
     * @return An array containing [confirmationCode, numberOfDiners],
     *         or null if no suitable candidate exists
     */
  /* public static int[] pickFirstMatchCandidate(Connection con) throws Exception {
        String sql =
            "SELECT w.ConfirmationCode, w.NumberOfDiners " +
            "FROM waitinglist w " +
            "WHERE w.status='WAITING' " +
            "  AND EXISTS (" +
            "    SELECT 1 FROM table t " +
            "    WHERE t.isActive=1 AND t.Seats >= w.NumberOfDiners" +
            "  ) " +
            "ORDER BY w.timeEnterQueue ASC " +
            "LIMIT 1";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (!rs.next()) return null;
            return new int[] {
                rs.getInt("ConfirmationCode"),
                rs.getInt("NumberOfDiners")
            };
        }
    }*/

  /* private static void expireOfferInternal(Connection con, int confCode, int resId, int tableNum) throws Exception {

	    TableRepository.releaseTable(con, tableNum);

	    boolean moved = returnToWaitlistEnd(con, confCode);
	    if (!moved) return;

	    String updRes = "UPDATE reservation SET Status='EXPIRED' WHERE ResId=? AND Status='OFFERED'";
	    try (PreparedStatement ps = con.prepareStatement(updRes)) {
	        ps.setInt(1, resId);
	        ps.executeUpdate();
	    }
	}*/

/*   public static boolean returnToWaitlistEnd(Connection con, int confCode) throws Exception {
	    String sql =
	            "UPDATE waitinglist " +
	            "SET status='WAITING', ResId=NULL, notifiedAt=NULL, acceptedAt=NULL, timeEnterQueue=NOW() " +
	            "WHERE ConfirmationCode=? AND status='OFFERED'";

	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, confCode);
	        return ps.executeUpdate() == 1;
	    }
	}*/



  /* public static String confirmReceiveTable(Connection con, int confCode) throws Exception {

	    ConfirmInfo info = getOfferByCode(con, confCode);
	    if (info == null) return "Invalid code or no active offer.";

	    long minutes = java.time.Duration.between(
	            info.notifiedAt.toInstant(),
	            java.time.Instant.now()
	    ).toMinutes();

	    if (minutes > 15) {
	        TableRepository.releaseTable(con, info.tableNum);

	
	        returnToWaitlistEnd(con, confCode);
	        try (PreparedStatement ps = con.prepareStatement(
	                "UPDATE reservation SET Status='EXPIRED' WHERE ResId=? AND Status='OFFERED'"
	        )) {
	            ps.setInt(1, info.resId);
	            ps.executeUpdate();
	        }

	        return "Offer expired. You were returned to the waitlist.";
	    }

	    boolean ok = markAccepted(con, confCode);
	    if (!ok) return "Offer already used or cancelled.";

	    try (PreparedStatement ps = con.prepareStatement(
	            "UPDATE reservation SET Status='ACTIVE' WHERE ResId=? AND Status='OFFERED'"
	    )) {
	        ps.setInt(1, info.resId);
	        ps.executeUpdate();
	    }

	    return "Table confirmed! Please go to table #" + info.tableNum;
	}
*/


    /**
     * Expires all offers that exceeded the 15-minute confirmation window.
     * Expired customers are returned to the end of the waiting queue,
     * and their reserved tables are released.
     *
     * @param con Active database connection
     * @return Number of expired offers processed
     */
 /*  public static int expireOffers(Connection con) throws Exception {
	    String sql =
	        "SELECT w.ConfirmationCode, w.ResId, r.TableNum " +
	        "FROM waitinglist w JOIN reservation r ON r.ResId = w.ResId " +
	        "WHERE w.status='OFFERED' " +
	        "AND w.notifiedAt IS NOT NULL " +
	        "AND NOW() > DATE_ADD(w.notifiedAt, INTERVAL 15 MINUTE)";

	    int count = 0;

	    try (PreparedStatement ps = con.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {

	        while (rs.next()) {
	            int conf = rs.getInt("ConfirmationCode");
	            int resId = rs.getInt("ResId");
	            int tableNum = rs.getInt("TableNum");

	            expireOfferInternal(con, conf, resId, tableNum);
	            count++;
	        }
	    }
	    return count;
	}*/


    /**
     * Handles expiration of a single offer.
     * The reserved table is released and the customer
     * is returned to the end of the waiting queue.
     *
     * @param con       Active database connection
     * @param confCode  Confirmation code of the customer
     * @param tableNum  Reserved table number
     */
  /* private static void expireOfferInternal(Connection con, int confCode, int tableNum) throws Exception {
        TableRepository.releaseTable(con, tableNum);

        String sql =
            "UPDATE waitinglist " +
            "SET status='WAITING', ResId=NULL, notifiedAt=NULL, acceptedAt=NULL, timeEnterQueue=NOW() " +
            "WHERE ConfirmationCode=? AND status='OFFERED'";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, confCode);
            ps.executeUpdate();
        }
    }*/

   /**
    * Represents a waiting-list candidate that may receive a table.
    * Holds the confirmation code, number of diners,
    * and either a customer ID or contact details.
    */
   /*public static class Candidate {

       // Unique confirmation code of the waiting-list entry
       public final int confCode;

       // Number of diners in the party
       public final int diners;

       // Customer ID if the person is a registered customer (can be null)
       public final Integer customerId;

       // Email address for non-registered customers
       public final String email;

       // Phone number for non-registered customers
       public final String phone;

       /**
        * Creates a Candidate object with all relevant waiting-list data.
        */
     /*  public Candidate(int confCode, int diners, Integer customerId, String email, String phone) {
           this.confCode = confCode;
           this.diners = diners;
           this.customerId = customerId;
           this.email = email;
           this.phone = phone;
       }
   }*/

   /**Added by maayan 12.1.26
    * Finds the first waiting customer (FIFO order)
    * whose party size can fit into the given number of seats.
    *
    * The method:
    * - Looks only at customers with status WAITING
    * - Filters customers whose party size is <= available seats
    * - Picks the earliest one in the queue
    *
    * @param con   Active database connection
    * @param seats Number of available seats
    * @return A Candidate object if found, or null if no one fits
    */
  /* public static Candidate pickNextFifoCandidateThatFits(Connection con, int seats) throws Exception {

       // SQL query that selects the earliest waiting customer that fits the table
       String sql =
           "SELECT ConfirmationCode, NumberOfDiners, costumerId, Email, Phone " +
           "FROM waitinglist " +
           "WHERE status='WAITING' AND NumberOfDiners <= ? " +
           "ORDER BY timeEnterQueue ASC " +
           "LIMIT 1";

       try (PreparedStatement ps = con.prepareStatement(sql)) {

           // Set the maximum number of diners allowed (available seats)
           ps.setInt(1, seats);

           try (ResultSet rs = ps.executeQuery()) {

               // If no suitable customer was found, return null
               if (!rs.next()) return null;

               // Read data of the selected waiting customer
               int code = rs.getInt("ConfirmationCode");
               int diners = rs.getInt("NumberOfDiners");
               Integer custId = (Integer) rs.getObject("costumerId");
               String email = rs.getString("Email");
               String phone = rs.getString("Phone");

               // Create and return a Candidate object
               return new Candidate(code, diners, custId, email, phone);
           }
       }
   }*/

   /*public static boolean markOffered(Connection con, int confCode, int resId) throws Exception {
	    String sql =
	        "UPDATE waitinglist " +
	        "SET status='OFFERED', notifiedAt=NOW(), ResId=? " +
	        "WHERE ConfirmationCode=? AND status='WAITING'";

	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, resId);
	        ps.setInt(2, confCode);
	        return ps.executeUpdate() == 1;
	    }
	}*/


	/*public static class ConfirmInfo {
	    public final int resId;
	    public final int tableNum;
	    public final java.sql.Timestamp notifiedAt;

	    public ConfirmInfo(int resId, int tableNum, java.sql.Timestamp notifiedAt) {
	        this.resId = resId;
	        this.tableNum = tableNum;
	        this.notifiedAt = notifiedAt;
	    }
	}*/

	/*public static ConfirmInfo getOfferByCode(Connection con, int confCode) throws Exception {
	    String sql =
	        "SELECT w.ResId, w.notifiedAt, r.TableNum " +
	        "FROM waitinglist w JOIN reservation r ON r.ResId = w.ResId " +
	        "WHERE w.ConfirmationCode=? AND w.status='OFFERED' " +
	        "LIMIT 1";

	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, confCode);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (!rs.next()) return null;
	            return new ConfirmInfo(
	                rs.getInt("ResId"),
	                rs.getInt("TableNum"),
	                rs.getTimestamp("notifiedAt")
	            );
	        }
	    }
	}
*/
	/*public static boolean markAccepted(Connection con, int confCode) throws Exception {
	    String sql =
	        "UPDATE waitinglist SET status='ACCEPTED', acceptedAt=NOW() " +
	        "WHERE ConfirmationCode=? AND status='OFFERED'";
	    try (PreparedStatement ps = con.prepareStatement(sql)) {
	        ps.setInt(1, confCode);
	        return ps.executeUpdate() == 1;
	    }
	}*/
	
	

    
//}