package common;

import java.io.Serializable;

public class BistroMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    private String command;     // סוג הפקודה, למשל: "login", "getMenu", "order"
    private Object data;        // מידע נלווה (Student, Faculty, רשימה, מספר... כל דבר)

    public BistroMessage(String command, Object data) {
        this.command = command;
        this.data = data;
    }

    public String getCommand() {
        return command;
    }

    public Object getData() {
        return data;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "BistroMessage{ command='" + command + "', data=" + data + " }";
    }
}
