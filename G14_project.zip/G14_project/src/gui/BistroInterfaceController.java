package gui;

import java.io.IOException;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class BistroInterfaceController {

    // חלון ראשי של הלקוח
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/BistroInterface.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root);
        primaryStage.setTitle("Restaurant Orders Client"); // שם יותר מתאים למטלה
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * כפתור Orders:
     * שולח לשרת בקשה לקבל את כל ההזמנות מהטבלה Order
     */
    @FXML
    private void onOrdersClick() {
        // מבקש מהשרת: getOrders -> השרת יקרא מה-DB וישלח בחזרה
        ClientUI.client.accept("getOrders");
    }

    /**
     * כפתור Tables:
     * במקום הסטטוס של שולחנות, נשתמש בו כדי לפתוח
     * את טופס עדכון ההזמנה (ReservationForm)
     */
    @FXML
    private void onTablesClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/ReservationForm.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Update Order");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * כפתור Menu:
     * לא דרוש במטלה – לא שולח כלום לשרת.
     * אפשר גם להסתיר/למחוק את הכפתור מה-FXML.
     */
    @FXML
    private void onMenuClick() {
        // לא נדרש במטלה, אפשר להשאיר ריק או להוריד את הכפתור מה-BistroInterface.fxml
        System.out.println("Menu button not used in this prototype.");
    }

    @FXML
    private void onExitClick() {
        System.exit(0);
    }
}
